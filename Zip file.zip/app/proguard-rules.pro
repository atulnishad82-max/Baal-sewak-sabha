# Proguard rules for Baal Sewak Sabha Android App
-keep class org.baalsewaksabha.app.model.** { *; }
