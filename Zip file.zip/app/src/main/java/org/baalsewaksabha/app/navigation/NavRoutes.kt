package org.baalsewaksabha.app.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "मुख्य", Icons.Default.Home)
    object MemberReg : Screen("member_reg", "सदस्यता", Icons.Default.PersonAdd)
    object Events : Screen("events", "आयोजन", Icons.Default.CalendarMonth)
    object Sewa : Screen("sewa", "सेवा", Icons.Default.VolunteerActivism)
    object Donation : Screen("donation", "दान", Icons.Default.Favorite)
    object Gallery : Screen("gallery", "दर्शन", Icons.Default.PhotoLibrary)
    object Announcements : Screen("announcements", "सूचना", Icons.Default.Campaign)
    object Contact : Screen("contact", "संपर्क", Icons.Default.Phone)
    object Admin : Screen("admin", "प्रशासन", Icons.Default.AdminPanelSettings)
}

val BottomNavItems = listOf(
    Screen.Home,
    Screen.MemberReg,
    Screen.Events,
    Screen.Donation,
    Screen.Admin
)
