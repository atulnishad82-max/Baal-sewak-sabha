package org.baalsewaksabha.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.baalsewaksabha.app.R
import org.baalsewaksabha.app.ui.theme.DeepMaroon
import org.baalsewaksabha.app.ui.theme.GoldCardBorder
import org.baalsewaksabha.app.ui.theme.SaffronDark

@Composable
fun SabhaHeader(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    colors = listOf(DeepMaroon, SaffronDark, DeepMaroon)
                )
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Original Baal Sewak Sabha Logo
            Image(
                painter = painterResource(id = R.drawable.sabha_logo),
                contentDescription = "Baal Sewak Sabha Logo",
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "बाल सेवक सभा ग्रुप",
                    color = Color(0xFFFEF3C7),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "हिन्दुस्तानी बस्ती, अमृतसर • सेवा परमो धर्मः",
                    color = Color(0xFFFDE68A),
                    fontSize = 11.sp
                )
            }
        }
    }
}
