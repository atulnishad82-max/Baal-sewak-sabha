package org.baalsewaksabha.app.model

data class Member(
    val id: String,
    val memberId: String,
    val name: String,
    val fatherOrHusbandName: String,
    val mobile: String,
    val address: String,
    val bloodGroup: String,
    val post: String = "सक्रिय सदस्य (Active Member)",
    val joinDate: String,
    val status: String = "approved",
    val photoUrl: String? = null
)

data class EventItem(
    val id: String,
    val title: String,
    val titleEn: String,
    val date: String,
    val time: String,
    val location: String,
    val description: String,
    val category: String,
    val attendeeCount: Int = 120
)

data class EventRegistration(
    val id: String,
    val regId: String,
    val eventId: String,
    val eventTitle: String,
    val name: String,
    val mobile: String,
    val attendeesCount: Int,
    val regDate: String,
    val status: String = "confirmed"
)

data class SewaRegistration(
    val id: String,
    val name: String,
    val mobile: String,
    val sewaType: String,
    val availability: String,
    val address: String,
    val regDate: String,
    val status: String = "active"
)

data class Donation(
    val id: String,
    val receiptNo: String,
    val donorName: String,
    val mobile: String,
    val amount: Double,
    val purpose: String,
    val date: String,
    val paymentMode: String = "UPI",
    val status: String = "success"
)

data class Announcement(
    val id: String,
    val title: String,
    val content: String,
    val date: String,
    val isUrgent: Boolean = false,
    val category: String = "सूचना"
)

data class GalleryItem(
    val id: String,
    val title: String,
    val category: String,
    val imageUrl: String
)
