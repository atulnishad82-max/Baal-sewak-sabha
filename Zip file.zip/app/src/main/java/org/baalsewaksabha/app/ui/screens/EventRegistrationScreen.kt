package org.baalsewaksabha.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import org.baalsewaksabha.app.data.SabhaRepository
import org.baalsewaksabha.app.model.EventItem
import org.baalsewaksabha.app.model.EventRegistration
import org.baalsewaksabha.app.ui.components.SabhaHeader
import org.baalsewaksabha.app.ui.theme.DeepMaroon
import org.baalsewaksabha.app.ui.theme.GoldCardBorder
import org.baalsewaksabha.app.ui.theme.SaffronDark
import org.baalsewaksabha.app.ui.theme.WarmBackground
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun EventRegistrationScreen(navController: NavController) {
    val context = LocalContext.current
    val events by SabhaRepository.events.collectAsState()
    var selectedEvent by remember { mutableStateOf<EventItem?>(null) }
    var generatedPass by remember { mutableStateOf<EventRegistration?>(null) }

    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var attendees by remember { mutableStateOf("1") }

    Scaffold(
        topBar = { SabhaHeader() },
        containerColor = WarmBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "धार्मिक एवं सेवा आयोजन (Sabha Events)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
                Text(
                    text = "मां भगवती चौकी, जागरण, स्वास्थ्य शिविर एवं विशेष पर्वों हेतु निःशुल्क प्रवेश पास बुक करें।",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            items(events) { event ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(3.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = event.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = DeepMaroon,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = event.category,
                                    fontSize = 11.sp,
                                    color = SaffronDark,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = event.titleEn,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = event.description,
                            fontSize = 12.sp,
                            color = Color(0xFF4B5563)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = SaffronDark, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "${event.date} • ${event.time}", fontSize = 11.sp, color = Color.Gray)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = SaffronDark, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = event.location, fontSize = 11.sp, color = Color.Gray)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { selectedEvent = event },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronDark),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("प्रवेश पास बुक करें (Book Event Pass)")
                        }
                    }
                }
            }
        }

        // Booking Dialog
        if (selectedEvent != null) {
            Dialog(onDismissRequest = { selectedEvent = null }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "प्रवेश पास पंजीकरण",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = DeepMaroon
                        )
                        Text(
                            text = selectedEvent?.title ?: "",
                            fontSize = 12.sp,
                            color = SaffronDark
                        )

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("आपका नाम (Full Name)*") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = mobile,
                            onValueChange = { if (it.length <= 10) mobile = it },
                            label = { Text("मोबाइल नंबर (Mobile)*") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = attendees,
                            onValueChange = { attendees = it },
                            label = { Text("व्यक्तियों की संख्या (Attendees)*") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(
                                onClick = { selectedEvent = null },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("रद्द करें")
                            }
                            Button(
                                onClick = {
                                    if (name.isBlank() || mobile.isBlank()) {
                                        Toast.makeText(context, "कृपया नाम व मोबाइल भरें", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    val count = attendees.toIntOrNull() ?: 1
                                    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                                    val newPass = EventRegistration(
                                        id = UUID.randomUUID().toString(),
                                        regId = "PASS-2026-${(1000..9999).random()}",
                                        eventId = selectedEvent!!.id,
                                        eventTitle = selectedEvent!!.title,
                                        name = name,
                                        mobile = mobile,
                                        attendeesCount = count,
                                        regDate = sdf.format(Date())
                                    )
                                    SabhaRepository.addEventRegistration(newPass)
                                    generatedPass = newPass
                                    selectedEvent = null
                                    name = ""
                                    mobile = ""
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronDark)
                            ) {
                                Text("पास पाएं")
                            }
                        }
                    }
                }
            }
        }

        // Generated Pass Dialog
        if (generatedPass != null) {
            val pass = generatedPass!!
            Dialog(onDismissRequest = { generatedPass = null }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .border(3.dp, GoldCardBorder, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "॥ बाल सेवक सभा प्रवेश पास ॥",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = SaffronDark
                        )
                        Text(
                            text = pass.eventTitle,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DeepMaroon
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .background(Color.White, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(90.dp))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "पास सं.: ${pass.regId}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(text = "धारक: ${pass.name} (${pass.attendeesCount} व्यक्ति)", fontSize = 12.sp)
                        Text(text = "मो.: ${pass.mobile}", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = { generatedPass = null },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronDark),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("बंद करें (Done)")
                        }
                    }
                }
            }
        }
    }
}
