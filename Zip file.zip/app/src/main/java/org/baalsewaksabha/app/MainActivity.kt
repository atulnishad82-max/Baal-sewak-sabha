package org.baalsewaksabha.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import org.baalsewaksabha.app.navigation.BottomNavItems
import org.baalsewaksabha.app.navigation.Screen
import org.baalsewaksabha.app.ui.screens.*
import org.baalsewaksabha.app.ui.theme.BaalSewakSabhaTheme
import org.baalsewaksabha.app.ui.theme.SaffronDark
import org.baalsewaksabha.app.ui.theme.WarmBackground

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BaalSewakSabhaTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                BottomNavItems.forEach { screen ->
                    val isSelected = currentRoute == screen.route
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title, fontSize = 10.sp) },
                        selected = isSelected,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SaffronDark,
                            selectedTextColor = SaffronDark,
                            indicatorColor = Color(0xFFFEF3C7)
                        ),
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(navController) }
            composable(Screen.MemberReg.route) { MemberRegistrationScreen(navController) }
            composable(Screen.Events.route) { EventRegistrationScreen(navController) }
            composable(Screen.Sewa.route) { SewaRegistrationScreen(navController) }
            composable(Screen.Donation.route) { DonationScreen(navController) }
            composable(Screen.Gallery.route) { GalleryScreen(navController) }
            composable(Screen.Announcements.route) { AnnouncementsScreen(navController) }
            composable(Screen.Contact.route) { ContactScreen(navController) }
            composable(Screen.Admin.route) { AdminScreen(navController) }
        }
    }
}
