package org.baalsewaksabha.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.baalsewaksabha.app.R
import org.baalsewaksabha.app.data.SabhaRepository
import org.baalsewaksabha.app.navigation.Screen
import org.baalsewaksabha.app.ui.components.SabhaHeader
import org.baalsewaksabha.app.ui.theme.*

@Composable
fun HomeScreen(
    navController: NavController
) {
    val events by SabhaRepository.events.collectAsState()
    val members by SabhaRepository.members.collectAsState()

    Scaffold(
        topBar = { SabhaHeader() },
        containerColor = WarmBackground
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }

            // 1. Sabha Official Emblem Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, GoldCardBorder, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.sabha_logo),
                            contentDescription = "Original Sabha Logo",
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "॥ आधिकारिक संगठन प्रतीक ॥",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            Text(
                                text = "बाल सेवक सभा ग्रुप",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = DeepMaroon
                            )
                            Text(
                                text = "हिन्दुस्तानी बस्ती, अमृतसर (पंजाब)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = AmberGolden
                            )
                            Text(
                                text = "मां भगवती की असीम अनुकंपा से 1998 से निरंतर समाज कल्याण व नित्य अन्नदान में समर्पित।",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }

            // 2. Auspicious Hero Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(SaffronDark, DeepMaroon)
                                )
                            )
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "Spiritual",
                                    tint = GoldCardBorder,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "जय माता दी • सेवा परमो धर्मः",
                                    color = Color(0xFFFEF3C7),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "परम पूज्य मां भगवती शेरावाली की छत्रछाया में निष्काम सेवा",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                StatBadge("50,000+", "लंगर थालियां")
                                StatBadge("${members.size}", "पंजीकृत सदस्य")
                                StatBadge("100%", "पारदर्शी सेवा")
                            }
                        }
                    }
                }
            }

            // 3. Quick Action Grid
            item {
                Text(
                    text = "त्वरित सेवाएं (Quick Services)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ActionCard(
                        title = "सदस्यता",
                        subtitle = "आईडी कार्ड पाएं",
                        icon = Icons.Default.PersonAdd,
                        color = Color(0xFFEA580C),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate(Screen.MemberReg.route) }

                    ActionCard(
                        title = "आयोजन",
                        subtitle = "प्रवेश पास",
                        icon = Icons.Default.CalendarMonth,
                        color = Color(0xFFB45309),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate(Screen.Events.route) }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ActionCard(
                        title = "सेवादान",
                        subtitle = "स्वयंसेवक बनें",
                        icon = Icons.Default.VolunteerActivism,
                        color = Color(0xFF059669),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate(Screen.Sewa.route) }

                    ActionCard(
                        title = "दान / भंडारा",
                        subtitle = "रसीद प्राप्त करें",
                        icon = Icons.Default.Favorite,
                        color = Color(0xFFDC2626),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate(Screen.Donation.route) }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ActionCard(
                        title = "दर्शन गैलरी",
                        subtitle = "फोटो व वीडियो",
                        icon = Icons.Default.PhotoLibrary,
                        color = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate(Screen.Gallery.route) }

                    ActionCard(
                        title = "संपर्क व आश्रम",
                        subtitle = "अमृतसर पता",
                        icon = Icons.Default.Phone,
                        color = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate(Screen.Contact.route) }
                }
            }

            // 4. Upcoming Events Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "आगामी धार्मिक व सेवा कार्यक्रम",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = DeepMaroon
                    )
                    TextButton(onClick = { navController.navigate(Screen.Events.route) }) {
                        Text("सभी देखें", color = SaffronPrimary, fontSize = 12.sp)
                    }
                }
            }

            items(events) { event ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = event.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = DeepMaroon
                            )
                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = event.category,
                                    fontSize = 10.sp,
                                    color = SaffronDark,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = "Date",
                                tint = Color.Gray,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${event.date} • ${event.time}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Location",
                                tint = Color.Gray,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = event.location,
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
fun StatBadge(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count,
            fontWeight = FontWeight.Black,
            fontSize = 15.sp,
            color = Color(0xFFFDE68A)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color(0xFFFEF3C7)
        )
    }
}

@Composable
fun ActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(color.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
        }
    }
}
