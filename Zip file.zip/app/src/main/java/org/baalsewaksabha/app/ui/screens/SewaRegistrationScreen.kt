package org.baalsewaksabha.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.baalsewaksabha.app.data.SabhaRepository
import org.baalsewaksabha.app.model.SewaRegistration
import org.baalsewaksabha.app.ui.components.SabhaHeader
import org.baalsewaksabha.app.ui.theme.DeepMaroon
import org.baalsewaksabha.app.ui.theme.EmeraldSuccess
import org.baalsewaksabha.app.ui.theme.SaffronDark
import org.baalsewaksabha.app.ui.theme.WarmBackground
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SewaRegistrationScreen(navController: NavController) {
    val context = LocalContext.current
    val sewaList by SabhaRepository.sewaRegistrations.collectAsState()

    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var sewaType by remember { mutableStateOf("नित्य लंगर सेवा (Daily Langar)") }
    var availability by remember { mutableStateOf("रविवार एवं पर्व (Sundays & Festivals)") }
    var address by remember { mutableStateOf("") }

    val sewaOptions = listOf(
        "नित्य लंगर सेवा (Daily Langar)",
        "जल एवं प्रसाद वितरण (Prasad Distribution)",
        "स्वच्छता सेवा (Sanitation Sewa)",
        "बाल संस्कार एवं शिक्षण (Moral Education)",
        "चिकित्सा शिविर सेवा (Medical Camp Helper)",
        "आयोजन प्रबंधन एवं सुरक्षा (Event Management)"
    )

    Scaffold(
        topBar = { SabhaHeader() },
        containerColor = WarmBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "निःस्वार्थ सेवा संकल्प (Sewa Volunteering)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
                Text(
                    text = "मां भगवती के दरबार एवं समाज के वंचितों की सेवा में अपना अमूल्य समय समर्पित करें।",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            // Registration Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "सेवक पंजीकरण फॉर्म",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = DeepMaroon
                        )

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("सेवक का नाम (Volunteer Name)*") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = mobile,
                            onValueChange = { if (it.length <= 10) mobile = it },
                            label = { Text("मोबाइल नंबर (Mobile)*") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text(text = "सेवा का प्रकार चुनें (Select Sewa Type):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        sewaOptions.forEach { option ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = (sewaType == option),
                                    onClick = { sewaType = option }
                                )
                                Text(text = option, fontSize = 12.sp)
                            }
                        }

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("निवास क्षेत्र / शहर (City/Area)*") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                if (name.isBlank() || mobile.isBlank()) {
                                    Toast.makeText(context, "कृपया नाम व मोबाइल भरें", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                                val newSewa = SewaRegistration(
                                    id = UUID.randomUUID().toString(),
                                    name = name,
                                    mobile = mobile,
                                    sewaType = sewaType,
                                    availability = availability,
                                    address = address,
                                    regDate = sdf.format(Date())
                                )
                                SabhaRepository.addSewaRegistration(newSewa)
                                Toast.makeText(context, "जय माता दी! आपका सेवा संकल्प पंजीकृत हुआ।", Toast.LENGTH_LONG).show()
                                name = ""
                                mobile = ""
                                address = ""
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.VolunteerActivism, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("सेवा संकल्प समर्पित करें (Enroll as Volunteer)")
                        }
                    }
                }
            }

            // Active Volunteers
            item {
                Text(
                    text = "पंजीकृत सेवादार (Enrolled Volunteers: ${sewaList.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
            }

            items(sewaList) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = item.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = item.sewaType, fontSize = 11.sp, color = SaffronDark)
                            Text(text = "पंजीकरण: ${item.regDate}", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}
