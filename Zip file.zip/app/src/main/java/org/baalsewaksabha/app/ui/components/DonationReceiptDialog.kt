package org.baalsewaksabha.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.baalsewaksabha.app.R
import org.baalsewaksabha.app.model.Donation
import org.baalsewaksabha.app.ui.theme.EmeraldSuccess
import org.baalsewaksabha.app.ui.theme.GoldCardBorder
import org.baalsewaksabha.app.ui.theme.SaffronDark

@Composable
fun DonationReceiptDialog(
    donation: Donation,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(2.dp, GoldCardBorder, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Receipt Header
                Image(
                    painter = painterResource(id = R.drawable.sabha_logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "बाल सेवक सभा ग्रुप, अमृतसर",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = SaffronDark
                )
                Text(
                    text = "॥ आधिकारिक दान रसीद ॥",
                    fontSize = 11.sp,
                    color = Color(0xFFB45309),
                    fontWeight = FontWeight.SemiBold
                )

                Divider(
                    color = Color(0xFFFDE68A),
                    thickness = 1.dp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "रसीद सं.:", fontSize = 12.sp, color = Color.Gray)
                    Text(text = donation.receiptNo, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "दिनांक:", fontSize = 12.sp, color = Color.Gray)
                    Text(text = donation.date, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "दानदाता:", fontSize = 12.sp, color = Color.Gray)
                    Text(text = donation.donorName, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "उद्देश्य:", fontSize = 12.sp, color = Color.Gray)
                    Text(text = donation.purpose, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFDCFCE7), RoundedCornerShape(8.dp))
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "राशि: ₹${donation.amount.toInt()}/- (प्राप्त)",
                        color = EmeraldSuccess,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronDark),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("स्वीकार एवं बंद करें (Close)")
                }
            }
        }
    }
}
