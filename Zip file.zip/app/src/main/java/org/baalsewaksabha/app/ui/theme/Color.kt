package org.baalsewaksabha.app.ui.theme

import androidx.compose.ui.graphics.Color

val SaffronPrimary = Color(0xFFEA580C)
val SaffronDark = Color(0xFF9A3412)
val AmberGolden = Color(0xFFD97706)
val DeepMaroon = Color(0xFF451A03)
val WarmBackground = Color(0xFFFFFBEB)
val GoldCardBorder = Color(0xFFFBBF24)
val SurfaceCard = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF292524)
val TextSecondary = Color(0xFF78716C)
val EmeraldSuccess = Color(0xFF059669)
