package org.baalsewaksabha.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import org.baalsewaksabha.app.R
import org.baalsewaksabha.app.data.SabhaRepository
import org.baalsewaksabha.app.ui.components.SabhaHeader
import org.baalsewaksabha.app.ui.theme.DeepMaroon
import org.baalsewaksabha.app.ui.theme.WarmBackground

@Composable
fun GalleryScreen(navController: NavController) {
    val items = SabhaRepository.galleryItems
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Langar", "Devotional", "Social", "Festival")

    Scaffold(
        topBar = { SabhaHeader() },
        containerColor = WarmBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "पवित्र दर्शन एवं छायाचित्र गैलरी",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = DeepMaroon
            )
            Text(
                text = "सभा के धार्मिक आयोजन, लंगर सेवा एवं बाल संस्कार शिविरों की पावन स्मृतियां।",
                fontSize = 12.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = (selectedCategory == cat),
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val filtered = if (selectedCategory == "All") items else items.filter { it.category == selectedCategory }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column {
                            AsyncImage(
                                model = item.imageUrl,
                                contentDescription = item.title,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Text(
                                text = item.title,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DeepMaroon,
                                modifier = Modifier.padding(8.dp),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
