package org.baalsewaksabha.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.baalsewaksabha.app.data.SabhaRepository
import org.baalsewaksabha.app.model.Donation
import org.baalsewaksabha.app.ui.components.DonationReceiptDialog
import org.baalsewaksabha.app.ui.components.SabhaHeader
import org.baalsewaksabha.app.ui.theme.DeepMaroon
import org.baalsewaksabha.app.ui.theme.EmeraldSuccess
import org.baalsewaksabha.app.ui.theme.SaffronDark
import org.baalsewaksabha.app.ui.theme.WarmBackground
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DonationScreen(navController: NavController) {
    val context = LocalContext.current
    var donorName by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("501") }
    var purpose by remember { mutableStateOf("नित्य लंगर महाप्रसाद सेवा") }
    var showReceipt by remember { mutableStateOf<Donation?>(null) }

    val presetAmounts = listOf("101", "251", "501", "1100", "2100", "5100")
    val purposeList = listOf(
        "नित्य लंगर महाप्रसाद सेवा",
        "अखंड ज्योति एवं जागरण सहयोग",
        "निर्धन बाल संस्कार व शिक्षण",
        "चिकित्सा व औषधि सहयोग",
        "सामान्य धर्मार्थ कोष"
    )

    Scaffold(
        topBar = { SabhaHeader() },
        containerColor = WarmBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "दान व सहयोग (Donation & Langar Sewa)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
                Text(
                    text = "आपके द्वारा दिया गया एक-एक रुपया नित्य अन्नदान, निर्धनों की शिक्षा और धर्म सेवा में समर्पित होता है।",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            // Donation Form Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(3.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "सहयोग राशि चुनें (Preset Amounts):",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = DeepMaroon
                        )

                        // Preset buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            presetAmounts.take(3).forEach { amt ->
                                OutlinedButton(
                                    onClick = { amountText = amt },
                                    modifier = Modifier.weight(1f),
                                    border = BorderStroke(
                                        1.5.dp,
                                        if (amountText == amt) SaffronDark else Color.LightGray
                                    ),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (amountText == amt) Color(0xFFFEF3C7) else Color.Transparent
                                    )
                                ) {
                                    Text("₹$amt", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            presetAmounts.drop(3).forEach { amt ->
                                OutlinedButton(
                                    onClick = { amountText = amt },
                                    modifier = Modifier.weight(1f),
                                    border = BorderStroke(
                                        1.5.dp,
                                        if (amountText == amt) SaffronDark else Color.LightGray
                                    ),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (amountText == amt) Color(0xFFFEF3C7) else Color.Transparent
                                    )
                                ) {
                                    Text("₹$amt", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("दान राशि (Custom Amount ₹)*") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = donorName,
                            onValueChange = { donorName = it },
                            label = { Text("दानदाता का शुभ नाम (Donor Name)*") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = mobile,
                            onValueChange = { if (it.length <= 10) mobile = it },
                            label = { Text("मोबाइल नंबर (Mobile)*") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text(text = "सहयोग का उद्देश्य (Purpose):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        purposeList.forEach { p ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = (purpose == p),
                                    onClick = { purpose = p }
                                )
                                Text(text = p, fontSize = 12.sp)
                            }
                        }

                        // Pay UPI Button
                        Button(
                            onClick = {
                                val amt = amountText.toDoubleOrNull()
                                if (amt == null || amt <= 0) {
                                    Toast.makeText(context, "कृपया वैध राशि दर्ज करें", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val finalName = donorName.ifBlank { "शुभ चिंतक (Wellwisher)" }
                                val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                                val donation = Donation(
                                    id = UUID.randomUUID().toString(),
                                    receiptNo = "BSS-REC-${(1000..9999).random()}",
                                    donorName = finalName,
                                    mobile = mobile,
                                    amount = amt,
                                    purpose = purpose,
                                    date = sdf.format(Date())
                                )
                                SabhaRepository.addDonation(donation)

                                // Attempt UPI deep link
                                try {
                                    val uri = Uri.parse("upi://pay?pa=baalsewaksabha@sbi&pn=BaalSewakSabha&am=$amt&cu=INR&tn=Donation")
                                    val intent = Intent(Intent.ACTION_VIEW, uri)
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    // Fallback to instant verified receipt
                                }

                                showReceipt = donation
                                Toast.makeText(context, "पुण्य कार्य हेतु धन्यवाद! रसीद तैयार है।", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronDark),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("सहयोग करें एवं रसीद प्राप्त करें (Donate ₹$amountText)")
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }

        // Receipt Modal
        if (showReceipt != null) {
            DonationReceiptDialog(
                donation = showReceipt!!,
                onDismiss = { showReceipt = null }
            )
        }
    }
}
