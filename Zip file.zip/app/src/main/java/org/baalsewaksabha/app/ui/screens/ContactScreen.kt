package org.baalsewaksabha.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.baalsewaksabha.app.ui.components.SabhaHeader
import org.baalsewaksabha.app.ui.theme.DeepMaroon
import org.baalsewaksabha.app.ui.theme.SaffronDark
import org.baalsewaksabha.app.ui.theme.WarmBackground

@Composable
fun ContactScreen(navController: NavController) {
    val context = LocalContext.current
    var queryName by remember { mutableStateOf("") }
    var queryMobile by remember { mutableStateOf("") }
    var queryMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = { SabhaHeader() },
        containerColor = WarmBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "संपर्क एवं आश्रम कार्यालय",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
                Text(
                    text = "बाल सेवक सभा मुख्यालय, हिन्दुस्तानी बस्ती, अमृतसर (पंजाब)।",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            // Quick Contact Cards
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+919876543210"))
                                    context.startActivity(intent)
                                }
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = SaffronDark)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "सेवादार हेल्पलाइन", fontSize = 11.sp, color = Color.Gray)
                                Text(text = "+91 98765 43210 / +91 98123 45678", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        Divider(color = Color(0xFFF3F4F6))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:sewa@baalsewaksabha.org"))
                                    context.startActivity(intent)
                                }
                        ) {
                            Icon(Icons.Default.Email, contentDescription = null, tint = SaffronDark)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "आधिकारिक ईमेल", fontSize = 11.sp, color = Color.Gray)
                                Text(text = "sewa@baalsewaksabha.org", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        Divider(color = Color(0xFFF3F4F6))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=Hindustani+Basti,+Amritsar,+Punjab"))
                                    context.startActivity(intent)
                                }
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = SaffronDark)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "सभा मुख्य पता", fontSize = 11.sp, color = Color.Gray)
                                Text(text = "हिन्दुस्तानी बस्ती, अमृतसर, पंजाब - 143001", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            // Inquiry Box
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "संदेश / सुझाव भेजें",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepMaroon
                        )
                        OutlinedTextField(
                            value = queryName,
                            onValueChange = { queryName = it },
                            label = { Text("आपका नाम") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = queryMobile,
                            onValueChange = { queryMobile = it },
                            label = { Text("मोबाइल नंबर") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = queryMessage,
                            onValueChange = { queryMessage = it },
                            label = { Text("आपका संदेश / जिज्ञासा") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )
                        Button(
                            onClick = {
                                if (queryName.isBlank() || queryMessage.isBlank()) {
                                    Toast.makeText(context, "कृपया नाम व संदेश भरें", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                Toast.makeText(context, "संदेश प्राप्त हुआ! शीघ्र संपर्क किया जाएगा।", Toast.LENGTH_LONG).show()
                                queryName = ""
                                queryMobile = ""
                                queryMessage = ""
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronDark),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("संदेश प्रेषित करें (Send Inquiry)")
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}
