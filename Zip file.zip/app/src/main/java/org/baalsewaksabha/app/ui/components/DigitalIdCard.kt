package org.baalsewaksabha.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.baalsewaksabha.app.R
import org.baalsewaksabha.app.model.Member
import org.baalsewaksabha.app.ui.theme.GoldCardBorder
import org.baalsewaksabha.app.ui.theme.SaffronDark
import org.baalsewaksabha.app.ui.theme.SaffronPrimary

@Composable
fun DigitalIdCard(
    member: Member,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(3.dp, GoldCardBorder, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(SaffronDark, SaffronPrimary, SaffronDark)
                    )
                )
                .padding(16.dp)
        ) {
            Column {
                // Card Top Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.sabha_logo),
                        contentDescription = "Sabha Logo",
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "BAAL SEWAK SABHA GROUP",
                            color = Color(0xFFFEF3C7),
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "हिन्दुस्तानी बस्ती, अमृतसर • आधिकारिक पहचान पत्र",
                            color = Color(0xFFFDE68A),
                            fontSize = 10.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verified",
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Divider(
                    color = Color(0x66FDE68A),
                    thickness = 1.dp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                // Member Information
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = member.name,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "पिता/पति: ${member.fatherOrHusbandName}",
                            color = Color(0xFFFEF3C7),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "सदस्यता सं.: ${member.memberId}",
                            color = Color(0xFFFDE68A),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "पद: ${member.post}",
                            color = Color.White,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "रक्त समूह: ${member.bloodGroup} • मो.: ${member.mobile}",
                            color = Color(0xFFFEF3C7),
                            fontSize = 11.sp
                        )
                        Text(
                            text = "निवास: ${member.address}",
                            color = Color(0xFFE2E8F0),
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    }

                    // QR Code Symbol
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "QR Code",
                            tint = Color.Black,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "पंजीकरण: ${member.joinDate}",
                        color = Color(0xFFFDE68A),
                        fontSize = 10.sp
                    )
                    Text(
                        text = "वैधता: आजीवन (Lifetime)",
                        color = Color(0xFFFDE68A),
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
