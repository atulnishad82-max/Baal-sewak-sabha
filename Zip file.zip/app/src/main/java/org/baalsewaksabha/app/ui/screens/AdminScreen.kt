package org.baalsewaksabha.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.baalsewaksabha.app.data.SabhaRepository
import org.baalsewaksabha.app.ui.components.SabhaHeader
import org.baalsewaksabha.app.ui.theme.DeepMaroon
import org.baalsewaksabha.app.ui.theme.EmeraldSuccess
import org.baalsewaksabha.app.ui.theme.SaffronDark
import org.baalsewaksabha.app.ui.theme.WarmBackground

@Composable
fun AdminScreen(navController: NavController) {
    val context = LocalContext.current
    var isAuthenticated by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }

    val members by SabhaRepository.members.collectAsState()
    val eventPasses by SabhaRepository.eventRegistrations.collectAsState()
    val sewaList by SabhaRepository.sewaRegistrations.collectAsState()
    val donations by SabhaRepository.donations.collectAsState()

    val totalDonations = donations.sumOf { it.amount }

    Scaffold(
        topBar = { SabhaHeader() },
        containerColor = WarmBackground
    ) { padding ->
        if (!isAuthenticated) {
            // PIN Login Screen
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(6.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .background(Color(0xFFFEF3C7), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = SaffronDark, modifier = Modifier.size(32.dp))
                        }

                        Text(
                            text = "प्रशासनिक सुरक्षा लॉगिन",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = DeepMaroon
                        )
                        Text(
                            text = "केंद्रीय समिति सदस्य पिन दर्ज करें (Default: BSS@2026)",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )

                        OutlinedTextField(
                            value = pin,
                            onValueChange = { pin = it },
                            label = { Text("सुरक्षा पिन (Admin PIN)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (pin.trim() == "BSS@2026" || pin.trim() == "1234") {
                                    isAuthenticated = true
                                    Toast.makeText(context, "प्रशासक सत्र सक्रिय!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "गलत पिन दर्ज किया गया", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronDark),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("सत्यापित करें (Unlock Admin)")
                        }
                    }
                }
            }
        } else {
            // Admin Dashboard
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "प्रशासन नियंत्रण कक्ष (Admin Portal)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = DeepMaroon
                        )
                        Text(text = "कुल दान: ₹${totalDonations.toInt()} | सदस्य: ${members.size}", fontSize = 11.sp, color = EmeraldSuccess)
                    }
                    IconButton(onClick = { isAuthenticated = false }) {
                        Icon(Icons.Default.Logout, contentDescription = "Logout", tint = Color.Red)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Tab Row
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.White,
                    contentColor = SaffronDark
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("सदस्य (${members.size})", fontSize = 11.sp) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("पास (${eventPasses.size})", fontSize = 11.sp) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("सेवादार (${sewaList.size})", fontSize = 11.sp) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("दान (${donations.size})", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (selectedTab) {
                        0 -> { // Members
                            items(members) { m ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(text = m.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(text = "आईडी: ${m.memberId} • मो.: ${m.mobile}", fontSize = 11.sp, color = Color.Gray)
                                            Text(text = m.post, fontSize = 10.sp, color = SaffronDark)
                                        }
                                        IconButton(onClick = {
                                            SabhaRepository.deleteMember(m.id)
                                            Toast.makeText(context, "हटाया गया", Toast.LENGTH_SHORT).show()
                                        }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray)
                                        }
                                    }
                                }
                            }
                        }
                        1 -> { // Event Passes
                            if (eventPasses.isEmpty()) {
                                item {
                                    Text("कोई नया पास नहीं है।", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(16.dp))
                                }
                            }
                            items(eventPasses) { pass ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(text = pass.eventTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = "पास सं.: ${pass.regId} • धारक: ${pass.name}", fontSize = 11.sp)
                                        Text(text = "व्यक्ति: ${pass.attendeesCount} • मो.: ${pass.mobile}", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                        2 -> { // Sewa
                            items(sewaList) { sw ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(text = sw.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = sw.sewaType, fontSize = 11.sp, color = SaffronDark)
                                        Text(text = "मो.: ${sw.mobile} • ${sw.address}", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                        3 -> { // Donations
                            items(donations) { don ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = don.donorName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(text = "${don.receiptNo} • ${don.purpose}", fontSize = 11.sp, color = Color.Gray)
                                            Text(text = "दिनांक: ${don.date}", fontSize = 10.sp, color = Color.Gray)
                                        }
                                        Text(
                                            text = "₹${don.amount.toInt()}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = EmeraldSuccess
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
