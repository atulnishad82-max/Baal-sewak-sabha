package org.baalsewaksabha.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.baalsewaksabha.app.data.SabhaRepository
import org.baalsewaksabha.app.model.Member
import org.baalsewaksabha.app.ui.components.DigitalIdCard
import org.baalsewaksabha.app.ui.components.SabhaHeader
import org.baalsewaksabha.app.ui.theme.DeepMaroon
import org.baalsewaksabha.app.ui.theme.SaffronDark
import org.baalsewaksabha.app.ui.theme.WarmBackground
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MemberRegistrationScreen(navController: NavController) {
    val context = LocalContext.current
    val members by SabhaRepository.members.collectAsState()

    var name by remember { mutableStateOf("") }
    var fatherOrHusbandName by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var bloodGroup by remember { mutableStateOf("O+") }
    var registeredMember by remember { mutableStateOf<Member?>(null) }

    Scaffold(
        topBar = { SabhaHeader() },
        containerColor = WarmBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "डिजिटल सदस्यता पंजीकरण (Member Registration)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepMaroon
                )
                Text(
                    text = "बाल सेवक सभा के आजीवन सदस्य बनें एवं क्यूआर कोड युक्त आधिकारिक पहचान पत्र प्राप्त करें।",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            // Generated Card Preview (if registered or sample)
            item {
                val previewMember = registeredMember ?: members.firstOrNull()
                if (previewMember != null) {
                    Text(
                        text = "॥ आपका डिजिटल पहचान पत्र (Preview) ॥",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = SaffronDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    DigitalIdCard(member = previewMember)
                }
            }

            // Registration Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "नया सदस्य फॉर्म भरें",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = DeepMaroon
                        )

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("सदस्य का पूरा नाम (Full Name)*") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = fatherOrHusbandName,
                            onValueChange = { fatherOrHusbandName = it },
                            label = { Text("पिता / पति का नाम (Father/Husband)*") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = mobile,
                            onValueChange = { if (it.length <= 10) mobile = it },
                            label = { Text("मोबाइल नंबर (10 Digit Mobile)*") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("पूर्ण निवास पता (Residential Address)*") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = bloodGroup,
                            onValueChange = { bloodGroup = it },
                            label = { Text("रक्त समूह (Blood Group e.g. B+, O+)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (name.isBlank() || mobile.isBlank() || address.isBlank()) {
                                    Toast.makeText(context, "कृपया सभी आवश्यक विवरण भरें", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                                val newMember = Member(
                                    id = UUID.randomUUID().toString(),
                                    memberId = "BSS-2026-${(100..999).random()}",
                                    name = name,
                                    fatherOrHusbandName = fatherOrHusbandName,
                                    mobile = mobile,
                                    address = address,
                                    bloodGroup = bloodGroup,
                                    joinDate = sdf.format(Date()),
                                    post = "सक्रिय सदस्य (Active Member)"
                                )
                                SabhaRepository.addMember(newMember)
                                registeredMember = newMember
                                Toast.makeText(context, "बधाई! आपका पहचान पत्र तैयार है।", Toast.LENGTH_LONG).show()
                                name = ""
                                fatherOrHusbandName = ""
                                mobile = ""
                                address = ""
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronDark),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("पंजीकरण करें एवं आईडी कार्ड बनाएं (Submit & Get ID)")
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}
