package org.baalsewaksabha.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.baalsewaksabha.app.model.*

object SabhaRepository {
    private val _members = MutableStateFlow<List<Member>>(listOf(
        Member(
            id = "m-1",
            memberId = "BSS-2026-001",
            name = "अतुल निषाद",
            fatherOrHusbandName = "श्री राम निषाद",
            mobile = "9876543210",
            address = "हिन्दुस्तानी बस्ती, अमृतसर, पंजाब",
            bloodGroup = "O+",
            post = "मुख्य संस्थापक एवं सेवादार",
            joinDate = "15 Jan 2026",
            status = "approved"
        ),
        Member(
            id = "m-2",
            memberId = "BSS-2026-002",
            name = "राजेश शर्मा",
            fatherOrHusbandName = "श्री ओमप्रकाश शर्मा",
            mobile = "9812345678",
            address = "कटरा शेर सिंह, अमृतसर",
            bloodGroup = "B+",
            post = "उपाध्यक्ष",
            joinDate = "20 Jan 2026",
            status = "approved"
        ),
        Member(
            id = "m-3",
            memberId = "BSS-2026-003",
            name = "सुनील कुमार",
            fatherOrHusbandName = "श्री मदन लाल",
            mobile = "9888877777",
            address = "पुतलीघर, अमृतसर",
            bloodGroup = "A+",
            post = "लंगर सेवा प्रमुख",
            joinDate = "01 Feb 2026",
            status = "approved"
        )
    ))
    val members: StateFlow<List<Member>> = _members.asStateFlow()

    private val _events = MutableStateFlow<List<EventItem>>(listOf(
        EventItem(
            id = "ev-1",
            title = "विशाल मां भगवती जागरण एवं चौकी",
            titleEn = "Grand Maa Bhagwati Jagran & Chowki",
            date = "18 Apr 2026",
            time = "रात्रि 8:00 बजे से प्रभु इच्छा तक",
            location = "सभा प्रांगण, हिन्दुस्तानी बस्ती, अमृतसर",
            description = "अमृतमयी भेंटें, दिव्य अखंड ज्योति दर्शन एवं प्रातः तारा रानी कथा व महाआरती।",
            category = "धार्मिक"
        ),
        EventItem(
            id = "ev-2",
            title = "नित्य महाप्रसाद एवं भंडारा लंगर सेवा",
            titleEn = "Daily Mahaprasad & Bhandara Langar",
            date = "प्रतिदिन (Daily)",
            time = "दोपहर 12:00 से 3:00 बजे",
            location = "अन्नपूर्णा भवन, हिन्दुस्तानी बस्ती, अमृतसर",
            description = "सभी भक्तजनों हेतु निःशुल्क पवित्र शुद्ध सात्विक भोजन लंगर सेवा।",
            category = "लंगर सेवा"
        ),
        EventItem(
            id = "ev-3",
            title = "निःशुल्क स्वास्थ्य जांच एवं नेत्र चिकित्सा शिविर",
            titleEn = "Free Multi-Speciality Health Camp",
            date = "25 Apr 2026",
            time = "प्रातः 9:00 से दोपहर 2:00 बजे",
            location = "सामुदायिक केंद्र, हिन्दुस्तानी बस्ती",
            description = "विशेषज्ञ डॉक्टरों द्वारा परामर्श, निःशुल्क दवाइयां एवं रक्तचाप व मधुमेह जांच।",
            category = "समाज सेवा"
        )
    ))
    val events: StateFlow<List<EventItem>> = _events.asStateFlow()

    private val _eventRegistrations = MutableStateFlow<List<EventRegistration>>(listOf())
    val eventRegistrations: StateFlow<List<EventRegistration>> = _eventRegistrations.asStateFlow()

    private val _sewaRegistrations = MutableStateFlow<List<SewaRegistration>>(listOf(
        SewaRegistration(
            id = "sw-1",
            name = "कमल वर्मा",
            mobile = "9822233344",
            sewaType = "लंगर वितरण सेवा",
            availability = "रविवार एवं पर्व",
            address = "अमृतसर",
            regDate = "02 Apr 2026"
        )
    ))
    val sewaRegistrations: StateFlow<List<SewaRegistration>> = _sewaRegistrations.asStateFlow()

    private val _donations = MutableStateFlow<List<Donation>>(listOf(
        Donation(
            id = "don-1",
            receiptNo = "BSS-REC-1001",
            donorName = "अतुल निषाद",
            mobile = "9876543210",
            amount = 2100.0,
            purpose = "नित्य लंगर अन्नदान सेवा",
            date = "01 Apr 2026"
        ),
        Donation(
            id = "don-2",
            receiptNo = "BSS-REC-1002",
            donorName = "गुप्त दानी (Anonymous)",
            mobile = "9800000000",
            amount = 5100.0,
            purpose = "जागरण एवं मंदिर जीर्णोद्धार",
            date = "03 Apr 2026"
        )
    ))
    val donations: StateFlow<List<Donation>> = _donations.asStateFlow()

    private val _announcements = MutableStateFlow<List<Announcement>>(listOf(
        Announcement(
            id = "an-1",
            title = "नवरात्र महोत्सव एवं अखंड ज्योति पंजीकरण आरंभ",
            content = "समस्त भक्तजनों को सूचित किया जाता है कि आगामी नवरात्र पर्व हेतु अखंड ज्योति एवं लंगर सेवा अग्रिम संकल्प आरंभ हो चुके हैं।",
            date = "04 Apr 2026",
            isUrgent = true,
            category = "उत्सव सूचना"
        ),
        Announcement(
            id = "an-2",
            title = "नया डिजिटल सदस्यता पहचान पत्र वितरण",
            content = "सभा के सभी पंजीकृत सदस्य अपने प्रोफाइल से क्यूआर कोड युक्त आधिकारिक पहचान पत्र डाउनलोड कर सकते हैं।",
            date = "02 Apr 2026",
            isUrgent = false,
            category = "सदस्यता"
        )
    ))
    val announcements: StateFlow<List<Announcement>> = _announcements.asStateFlow()

    val galleryItems = listOf(
        GalleryItem("1", "अन्नपूर्णा लंगर सेवा", "Langar", "https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=600&q=80"),
        GalleryItem("2", "मां भगवती श्रृंगार दर्शन", "Devotional", "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80"),
        GalleryItem("3", "बाल संस्कार एवं शिक्षा शिविर", "Social", "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=600&q=80"),
        GalleryItem("4", "दीपोत्सव एवं महाआरती", "Festival", "https://images.unsplash.com/photo-1609137144822-2615569429b3?auto=format&fit=crop&w=600&q=80")
    )

    fun addMember(member: Member) {
        _members.value = listOf(member) + _members.value
    }

    fun addEventRegistration(reg: EventRegistration) {
        _eventRegistrations.value = listOf(reg) + _eventRegistrations.value
    }

    fun addSewaRegistration(sewa: SewaRegistration) {
        _sewaRegistrations.value = listOf(sewa) + _sewaRegistrations.value
    }

    fun addDonation(donation: Donation) {
        _donations.value = listOf(donation) + _donations.value
    }

    fun updateMemberStatus(id: String, newStatus: String) {
        _members.value = _members.value.map { if (it.id == id) it.copy(status = newStatus) else it }
    }

    fun deleteMember(id: String) {
        _members.value = _members.value.filter { it.id !== id }
    }
}
